#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include"adc.h"
#include"update_ADC_result.h"
#include "checking_noise_ADC.h"
//#include "convert_data_to_LED.h"
//#include "check_LED.h"

static uint8_t lcd_buffer[] = "    WXYZ ";
extern int timer_flag;
extern volatile uint16_t gADC_Result;
extern char statusADC[3];
extern float data_ADC;
unsigned long b;
/******************************************************************************
* Function Name: update_ADC_result
* Description  : update ADC result
* Arguments    : none
* Return Value : none
******************************************************************************/
void update_ADC_result(void){
	

		/* Start an A/D conversion */
		ADC_Start();
		
		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);
		    
                /* Clear ADC flag */
		Adc_Status = 0;
		
		/* Shift the ADC result contained in the 16-bit ADCR register */
		gADC_Result = ADCR >> 6;
		data_ADC= (float)(gADC_Result);
		
		
		/*check overall error*/
		checking_noise_ADC();
		
		/* Convert ADC result into voltage value*/
		 data_ADC= (data_ADC*999)/1023;
	
		  
	        b=(unsigned int )(data_ADC);//+0.5); 

		
	    /* Convert ADC result into a character string, and store in the local */
		
                //b=(unsigned long)(a*100);
		lcd_buffer[5] = (uint8_t)(b/100+'0');
		lcd_buffer[6] = (uint8_t)((b%100)/10+'0');
		lcd_buffer[7] = (uint8_t)((b%100)%10+'0');
		statusADC[2]= (char)(lcd_buffer[5]);
		statusADC[1]= (char)(lcd_buffer[6]);
		statusADC[0]= (char)(lcd_buffer[7]);
		
		
		//DisplayLCD(LCD_LINE7, (const uint8_t*)lcd_buffer);
	  
	}
	
	