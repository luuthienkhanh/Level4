
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include "ports.h"
#include "api.h"
#include "data_transmit.h"

extern int timer_flag;
extern char statusLEDs[4];
extern char statusADC[3];

/******************************************************************************
* Function Name: data_transmit
* Description  : data transmit
* Arguments    : none
* Return Value : none
******************************************************************************/


void data_transmit(void){
     char str1[1] = "$";
     char str2[4] = "2020";
     char str3[1] = ",";
     char str4[1] = "L";
     char str5[1] = "^";
     char str6[1]  ="A";

      if(1 == timer_flag)
      { //Transmit Status LED
        Uart_Transmit(&(str1[0]), 1);
        Uart_Transmit(&(str2[0]), 4);
        Uart_Transmit(&(str3[0]), 1);
        Uart_Transmit(&(str4[0]), 1);
	Uart_Transmit(&(statusLEDs[3]), 1);
	Uart_Transmit(&(statusLEDs[2]), 1);
	Uart_Transmit(&(statusLEDs[1]), 1);
	Uart_Transmit(&(statusLEDs[0]), 1);
	Uart_Transmit(&(str5[0]), 1);
	
	//Transmit Status ADC
	Uart_Transmit(&(str1[0]), 1);
        Uart_Transmit(&(str2[0]), 4);
        Uart_Transmit(&(str3[0]), 1);
	Uart_Transmit(&(str6[0]), 1);
	Uart_Transmit(&(statusADC[2]), 1);
	Uart_Transmit(&(statusADC[1]), 1);
	Uart_Transmit(&(statusADC[0]), 1);
	Uart_Transmit(&(str5[0]), 1);
	
	timer_flag = 0;
      }
      else
      {
        /* Do nohing */
      }
	
}