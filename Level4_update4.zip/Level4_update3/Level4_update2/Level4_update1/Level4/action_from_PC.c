
#include "lcd.h"
#include "iodefine.h"
#include "stdlib.h"
#include "uart.h"
#include "LED_status.h"
#include "action_from_PC.h"

int LED_ID_number;
extern int display_text_on_LCD;
extern unsigned char line_text;
extern char text_from_PC1[UART_RX_BUFFER_LEN];
extern unsigned int LEDs1[13];
void action_from_PC(void){
      if (display_text_on_LCD==1){
      DisplayLCD(line_text,(uint8_t *)text_from_PC1);
      }else {
	     if (text_from_PC1[0]=='1') {
	        if(text_from_PC1[2]==','){
		LED_ID_number =	(int)(text_from_PC1[0]-'0');
		LED_ID_number =LED_ID_number *10+(int)(text_from_PC1[1]-'0');
		LEDs1[LED_ID_number-3]=((int)(text_from_PC1[3]-'0'))^1;
		}
      }else {
	      LED_ID_number =	(int)(text_from_PC1[0]-'0');
	      LEDs1[LED_ID_number-3]=((int)(text_from_PC1[2]-'0'))^1;
      }
}
}

