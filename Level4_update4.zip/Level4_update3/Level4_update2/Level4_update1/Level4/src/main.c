/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "adc.h" 
#include "sw.h"
#include "timer.h"
#include "UART_receive.h"
#include"UART_transmit.h"
#include "ports.h"
#include "api.h"
#include "LED_status.h"
#include "convert_digital_data.h"
#include "action_from_PC.h"

/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void LCD_Reset(void);
int error_parity=0;
unsigned long t =10*1778;
/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;
float data_ADC;
int timer_flag=0;
char text_from_PC[UART_RX_BUFFER_LEN];
char text_from_PC1[UART_RX_BUFFER_LEN];
char statusLEDs[4]={'0','0','0','0'};//,'\0'};
char statusADC[3]={'0','0','0'};
unsigned int LEDs1[13]={1,1,1,1,1,1,1,1,1,1,1,1,1};
int display_text_on_LCD;
unsigned char line_text;

/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)  
{   
     /* Initialize ADC module */
     ADC_Create();
     ADC_Set_OperationOn();
	
	
    /* Initialize timer */
    timer_init();
    
     /* Initialize LED */
     int_port();
     
    
    /* Initialize UART1 communication */
    Uart_Init();
    
    /* Initialize external interrupt - SW1 */
    INTC_Create();
    
    /* Enable interrupt */
    EI();
    
    LCD_Reset();
    
    /* Initialize SPI channel used for LCD */
    R_SPI_Init(SPI_LCD_CHANNEL);
	
    /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
    R_SPI_SslInit(
    SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
    (unsigned char *)&P14,   /* Select Port register */
    (unsigned char *)&PM14,  /* Select Port mode register */
    5,                       /* Select pin index in the port */
    0,                       /* Configure CS pin active state, 0 means active LOW level  */
    0                        /* Configure CS pin active mode, 0 means active per transfer */
    );
    
    /* Initialize LCD driver */
    InitialiseLCD();

    /* Clear LCD display */
    ClearLCD();
    
    /* Display information on the debug LCD.*/
    DisplayLCD(LCD_LINE1, (uint8_t *)"  UART  ");
    DisplayLCD(LCD_LINE2, (uint8_t *)"Interface");
    
    /* Start UART1 communication */
    Uart_Start();
  
    /* Start external interrupt - SW1 */
    INTC10_Start();
  
    /* Start timer */
    timer_start();

    while (1U)
    {   
      UART_receive();
      action_from_PC();
     LED_status();
     convert_digital_data();
     UART_transmit();
 
 
    }
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}
/******************************************************************************
End of file
******************************************************************************/
