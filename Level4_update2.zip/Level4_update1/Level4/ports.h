#ifndef PORTS_H
#define PORTS_H

#define PORT6 (unsigned char *)0xFFF06//red leds ;6
#define PORTM6 (unsigned char *)0xFFF26

#define PORT4 (unsigned char *)0xFFF04// green leds 4.2-4.5; 4
#define PORTM4 (unsigned char *)0xFFF24

#define PORT10 (unsigned char *)0xFFF0A//green 10.1; 1
#define PORTM10 (unsigned char *)0xFFF2A

#define PORT15 (unsigned char *)0xFFF0F//green 15.2; 1
#define PORTM15 (unsigned char *)0xFFF2F

#define PORT15_AD (unsigned char *)0xF0076

//Define LEDs with their address
//Note: For Switch 1-2-3, you will use 
//SFR in function main.c

#endif