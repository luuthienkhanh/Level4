#ifndef API_H
#define API_H

#include "ports.h"

//Off all the LEDs
void offLED(void);


//On all the LEDs
void onLED(void);

//initial port
void int_port(void);

//Wait for M mili-second
void wait(unsigned long M);
#endif