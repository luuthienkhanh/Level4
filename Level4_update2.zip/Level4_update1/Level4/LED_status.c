#include "lcd.h"
#include "iodefine.h"
#include "LED_status.h"


unsigned int LEDs[13]={0,0,0,0,0,0,0,0,0,0,0,0,0};
unsigned int x2[4];//={1U,1U,1U,1U};
//char HEX[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F"};
unsigned char HEX[16]="0123456789ABCDEF";

extern char statusLEDs[4];


extern int timer_flag;

void LED_status(void){
	unsigned int i=0;
	unsigned int j=0;
	unsigned int t=0;
	unsigned int k=0;
	unsigned int a=0;
	x2[3]=8;
	x2[2]=4;
	x2[1]=2;
	x2[0]=1;
	P4_bit.no1=0;
	P10_bit.no1=0;
	P6_bit.no7=1;
	P15_bit.no2=0;
	P6_bit.no6=1;
	P4_bit.no5=0;
	P6_bit.no5=1;
	P4_bit.no4=0;
	P6_bit.no4=1;
	P4_bit.no3=0;
	P6_bit.no3=1;
	P4_bit.no2=0;
	P6_bit.no2=1;
	LEDs[12]=P4_bit.no1;
	LEDs[11]=P10_bit.no1;
	LEDs[10]=P6_bit.no7;
	LEDs[9]=P15_bit.no2;
	LEDs[8]=P6_bit.no6;
	LEDs[7]=P4_bit.no5;
	LEDs[6]=P6_bit.no5;
	LEDs[5]=P4_bit.no4;
	LEDs[4]=P6_bit.no4;
	LEDs[3]=P4_bit.no3;
	LEDs[2]=P6_bit.no3;
	LEDs[1]=P4_bit.no2;
	LEDs[0]=P6_bit.no2;
	 //if(1 == timer_flag){
	 for (i=0;i<=12;i++){
		LEDs[i]=LEDs[i]^1; 
	 }
	 if (LEDs[12]==1){
		statusLEDs[3]=HEX[1];
	 }else  statusLEDs[3]=HEX[0];
	 
	 for (i=0;i<=2;i++){
		if (t<=8){
		for (j=t;j<=t+3;j++){
		a=a+LEDs[j]*x2[k];
		k=k+1;
		}
		k=0;
		}else t=0;
		t=t+4;
		statusLEDs[i]=HEX[a];
		a=0;
	 }
	
	 
	 
	 
}
	
	
	
	
