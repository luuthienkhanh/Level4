
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include"UART_receive.h"


void UART_receive(void){
	
         unsigned char LCD_Line = LCD_LINE3;
    
	/* Check UART1 receive status */
        if(status == UART_RECEIVE_DONE)
        {
        
        status = 0;
	
	/* Replace the last element by NULL */
        rx_buff[UART_RX_BUFFER_LEN - 1] = '\0';
	
	/* 
	
	
	
        /* Display string in receive buffer */
	DisplayLCD(LCD_Line, (uint8_t *)(&rx_buff[5]));
	
	/* Cheking for display in next line */
	if(0 == (rx_count%12))
	{
           Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
	   LCD_Line = (unsigned char)(rx_count/12)*8 + LCD_LINE3;
	}
	else
	{
	  /* Do nothing */
	}
      }
      else if (UART_CLEAR == cmd)
      {
        cmd = 0;
	rx_count = 0;
        ClearLCD();
        DisplayLCD(LCD_LINE1, (uint8_t *)"  UART  ");
        DisplayLCD(LCD_LINE2, (uint8_t *)"Interface");
        Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
	LCD_Line = LCD_LINE3;
      }
      else
      {
        /* Do nothing */
      }
	
}