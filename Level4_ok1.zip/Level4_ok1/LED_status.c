#include "lcd.h"
#include "iodefine.h"
#include "LED_status.h"


unsigned int LEDs[13]={0,0,0,0,0,0,0,0,0,0,0,0,0};
extern unsigned int LEDs1[13];
unsigned char HEX[16]="0123456789ABCDEF";
unsigned int x2[4];

extern char statusLEDs[4];


extern int timer_flag;

void LED_status(void){
	unsigned int i=0;
	unsigned int j=0;
	unsigned int t=0;
	unsigned int k=0;
	unsigned int a=0;
	x2[3]=8;
	x2[2]=4;
	x2[1]=2;
	x2[0]=1;
	
	
	P4_bit.no1=LEDs1[12];
	P10_bit.no1=LEDs1[11];
	P6_bit.no7=LEDs1[10];
	P15_bit.no2=LEDs1[9];
	P6_bit.no6=LEDs1[8];
	P4_bit.no5=LEDs1[7];
	P6_bit.no5=LEDs1[6];
	P4_bit.no4=LEDs1[5];
	P6_bit.no4=LEDs1[4];
	P4_bit.no3=LEDs1[3];
	P6_bit.no3=LEDs1[2];
	P4_bit.no2=LEDs1[1];
	P6_bit.no2=LEDs1[0];
	
	LEDs[12]=P4_bit.no1;
	LEDs[11]=P10_bit.no1;
	LEDs[10]=P6_bit.no7;
	LEDs[9]=P15_bit.no2;
	LEDs[8]=P6_bit.no6;
	LEDs[7]=P4_bit.no5;
	LEDs[6]=P6_bit.no5;
	LEDs[5]=P4_bit.no4;
	LEDs[4]=P6_bit.no4;
	LEDs[3]=P4_bit.no3;
	LEDs[2]=P6_bit.no3;
	LEDs[1]=P4_bit.no2;
	LEDs[0]=P6_bit.no2;

	 for (i=0;i<=12;i++){
		LEDs[i]=LEDs[i]^1; 
	 }
	 if (LEDs[12]==1){
		statusLEDs[3]=HEX[1];
	 }else  statusLEDs[3]=HEX[0];
	 
	 for (i=0;i<=2;i++){
		if (t<=8){
		for (j=t;j<=t+3;j++){
		a=a+LEDs[j]*x2[k];
		k=k+1;
		}
		k=0;
		}else t=0;
		t=t+4;
		statusLEDs[i]=HEX[a];
		a=0;
	 }
	 
//	 for (i=0;i<=12;i++){
//		LEDs1[i]=LEDs1[i]^1; 
//	 }
//	 if (LEDs1[12]==1){
//		statusLEDs[3]=HEX[1];
//	 }else  statusLEDs[3]=HEX[0];
//	 
//	 for (i=0;i<=2;i++){
//		if (t<=8){
//		for (j=t;j<=t+3;j++){
//		a=a+LEDs1[j]*x2[k];
//		k=k+1;
//		}
//		k=0;
//		}else t=0;
//		t=t+4;
//		statusLEDs[i]=HEX[a];
//		a=0;
//	 }
	
	 
	 
	 
}
	
	
	
	
