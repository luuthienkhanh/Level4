
#include "lcd.h"
#include "iodefine.h"
#include "stdlib.h"
#include "uart.h"
#include "LED_status.h"
#include "action_from_PC.h"

int LED_ID_number_check;
extern int display_text_on_LCD;
extern unsigned char line_text;
extern char text_from_PC1[UART_RX_BUFFER_LEN];
extern unsigned int LEDs1[13];
extern int Msg_Err;
extern unsigned int check_state_A;
extern char text_from_PC[UART_RX_BUFFER_LEN];
extern unsigned char line_text;
extern unsigned int LED_ID_number;
extern int check_error_data;
//('0'<=text_from_PC1[0]<'3'&&text_from_PC1[1]==',')
//void checking_msg_error(void){
//	 if(display_text_on_LCD==0){
//                if ('0'<=text_from_PC1[0]&&text_from_PC1[0]<'3'&&(text_from_PC1[1]==',')){
//			Msg_Err=1;
//			
//		}else {
//		      LED_ID_number_check =(int)(text_from_PC1[0]-'0');
//		      LED_ID_number_check =LED_ID_number_check *10+(int)(text_from_PC1[1]-'0');
//		      if (LED_ID_number_check>15){
//			      Msg_Err=1;
//		      }else Msg_Err=0;
//		
//		}
//		      
//}else {
//	   if (line_text>56){
//		   Msg_Err=1;
//	 }
//}
//}
		            		      
void checking_msg_error(void){
	if(check_error_data==1){
		if(display_text_on_LCD==0){
			if (3U<=LED_ID_number){
				if(LED_ID_number<=15U){
			          Msg_Err=0;
				}
	           }else {Msg_Err=1;
	               check_error_data=0;
		   }
}
	}
}
