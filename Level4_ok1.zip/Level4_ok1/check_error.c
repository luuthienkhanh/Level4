#include "check_error.h"	
float current;
float previous;
extern float data_ADC;
int getADC_result_fisrt=0;
float overall;	


/******************************************************************************
* Function Name: check_error
* Description  : check overall error
* Arguments    : none
* Return Value : none
******************************************************************************/
	
void check_error(void){
	        
	        overall=1.2;
		if (getADC_result_fisrt==0){// update previous data and current data  if it is the first time get ADC result
		previous=data_ADC;
		getADC_result_fisrt=1;
		}else{ 
		previous=current;//update previous data
		current=data_ADC;//update current data
		if ((current >=(previous - overall))&&(current <=(previous + overall))){ //if current data is available in condition of ovearall error
		current=previous;//update current data
		data_ADC=previous;
		
		}
		else 
		{
		 data_ADC=current;
		}
               }
	}

