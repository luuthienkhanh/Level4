
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include"UART_receive.h"

//char text_from_PC[UART_RX_BUFFER_LEN];
extern char text_from_PC[UART_RX_BUFFER_LEN];
extern unsigned char line_text;
extern char text_from_PC1[UART_RX_BUFFER_LEN];
int lenght_data_display=0;
extern int display_text_on_LCD;
extern int check_error_data;
extern unsigned int LED_ID_number;
//extern int send_text_flag;
void UART_receive(void){
	int i=0;
        unsigned char LCD_Line = LCD_LINE3;
        
	/* Check UART1 receive status */
        if(status == UART_RECEIVE_DONE)
        {
        
        status = 0;
	
	/* Replace the last element by NULL */
        rx_buff[UART_RX_BUFFER_LEN - 1] = '\0';
	

	/////////////////////////////////////
	if (text_from_PC[1]=='T'){
		//send_text_flag=1;
		  for (i=0;i<24;i++)
	{       
        text_from_PC1[i]='\0';
	}
      
         line_text=((text_from_PC[3])-'1')*8;
	 display_text_on_LCD=1;
	         for (i=5;i<(rx_count-1);i++)
	{       
        text_from_PC1[i-5]=text_from_PC[i];
	}
		       
	
	}else if (text_from_PC[1]=='L'){
	display_text_on_LCD=0;	
	       for (i=3;i<(rx_count-1);i++)
	{       
        text_from_PC1[i-3]=text_from_PC[i];
	}
	}

	///////////////////////////////////// 
      }
      else if (UART_CLEAR == cmd)
      {
        cmd = 0;
	rx_count = 0;
        ClearLCD();
        Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
	Uart_ClearBuff(&text_from_PC[0], UART_RX_BUFFER_LEN - 1);
	//check_error_data=0;
	//LED_ID_number=3;
      }
      else
      {
        /* Do nothing */
      }

      	
}