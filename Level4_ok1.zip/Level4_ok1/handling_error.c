#include "lcd.h"
#include "iodefine.h"
#include "uart.h"
#include "timer.h"
#include "adc.h"
#include "sw.h"
#include "handling_error.h"
extern unsigned char line_text;
extern int error_parity;
extern int Msg_Err;
void handling_error(void){

	if (Msg_Err==1){
	P1_bit.no0=1;
	DisplayLCD(LCD_LINE8,(uint8_t *)"Msg Err");
        Uart_Stop();
	timer_stop();
	line_text=0;
	INTC10_Start();
	INTC_Create();
	ADC_Stop();
	
	}
	
}



	/*if ((SSR03&0x0002==0x0002)||(SSR03&0x0004==0x0004)){
	error_parity=1;
	SIR03=0x0007;
	P1_bit.no0=1;
	DisplayLCD(LCD_LINE8,(uint8_t *)"UART Err");
	//Uart_Stop();
	}*/