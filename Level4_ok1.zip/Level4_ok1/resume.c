#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "iodefine.h"
#include "ports.h"
#include "api.h"
#include "adc.h" 
#include "uart.h"
#include "sw.h"
#include "timer.h"
#include "resume.h"

extern int Msg_Err;
extern int error_parity;
extern unsigned int check_state_A;
extern char text_from_PC1[UART_RX_BUFFER_LEN];
void resume(void){
	if( (P7&0x20) == 0x00){
	if (Msg_Err==1){
	        int i;
		P1_bit.no0= 0;
		DisplayLCD(LCD_LINE8,(uint8_t *)"        ");
		//gSwitchFlag = '0';
		Msg_Err=0;
		
		for (i=0;i<=24;i++){
	        text_from_PC1[i]='\0';
		
		/* Initialize ADC module */
     		ADC_Create();
     		ADC_Set_OperationOn();
	
	
   		 /* Initialize timer */
    		timer_init();
    
     		/* Initialize LED */
     		int_port();
     
    
    		/* Initialize UART1 communication */
    		Uart_Init();
    
    		/* Initialize external interrupt - SW1 */
    		INTC_Create();
    
    		/* Enable interrupt */
    		EI();
    
		//    LCD_Reset();
    
    		/* Initialize SPI channel used for LCD */
   		 R_SPI_Init(SPI_LCD_CHANNEL);
    
    		Uart_Start();
		timer_start();
		/* Start an A/D conversion */
		ADC_Start();
	
}
}
	}
}
