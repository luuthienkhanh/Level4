
#include "lcd.h"
#include "iodefine.h"
#include "stdlib.h"
#include "uart.h"
#include "LED_status.h"
#include "action_from_PC.h"
#include "checking_error.h"

extern unsigned int LED_ID_number;
extern unsigned int check_state_A;
extern int display_text_on_LCD;
extern unsigned char line_text;
extern char text_from_PC1[UART_RX_BUFFER_LEN];
extern unsigned int LEDs1[13];
extern int check_error_data;
void action_from_PC(void){
      if (display_text_on_LCD==1){
      DisplayLCD(line_text,(uint8_t *)text_from_PC1);
      }else {
	     if (text_from_PC1[0]=='1') {
	        if(text_from_PC1[2]==','){
		LED_ID_number =	(unsigned int)(text_from_PC1[0]-'0');
		LED_ID_number =(unsigned int)(LED_ID_number *10)+(unsigned int)(text_from_PC1[1]-'0');
		LEDs1[LED_ID_number-3]=((unsigned int)(text_from_PC1[3]-'0'))^1;
		checking_msg_error();
		}
      }else {
	      LED_ID_number =	(unsigned int)(text_from_PC1[0]-'0');
	      LEDs1[LED_ID_number-3]=((unsigned int)(text_from_PC1[2]-'0'))^1;    
	     checking_msg_error();
      }
}
}

